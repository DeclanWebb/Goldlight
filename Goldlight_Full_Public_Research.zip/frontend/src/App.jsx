
import React from "react";

export default function App() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Goldlight</h1>
      <p><em>A place to notice what’s usually missed.</em></p>

      <section>
        <p>
          Goldlight is a free, public research project exploring responsible and ethical
          uses of artificial intelligence to support reflection and human connection.
        </p>
        <p>
          This platform is not therapy, medical care, or a crisis service.
        </p>
      </section>

      <nav>
        <ul>
          <li>Home</li>
          <li>Workshops</li>
          <li>AI Support</li>
          <li>Emergency Resources</li>
          <li>About Goldlight</li>
        </ul>
      </nav>
    </main>
  );
}
